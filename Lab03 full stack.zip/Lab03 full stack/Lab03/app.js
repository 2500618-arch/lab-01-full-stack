const studentName = document.getElementById("studentName");
const marks = document.getElementById("marks");
const calculateBtn = document.getElementById("calculateBtn");
const result = document.getElementById("result");

calculateBtn.addEventListener("click", function () {
    const name = studentName.value.trim();
    const marksValue = marks.value;

    result.className = "";

    // Bonus: validate empty values
    if (name === "" || marksValue === "") {
        result.textContent = "Please enter student name and marks.";
        result.classList.add("error");
        return;
    }

    const score = Number(marksValue);

    // Bonus: validate marks range
    if (score < 0 || score > 100 || Number.isNaN(score)) {
        result.textContent = "Marks must be between 0 and 100.";
        result.classList.add("error");
        return;
    }

    let grade;

    if (score >= 85) {
        grade = "A";
    } else if (score >= 70) {
        grade = "B";
    } else if (score >= 50) {
        grade = "C";
    } else {
        grade = "F";
    }

    result.textContent = `${name} scored ${score} → Grade ${grade}`;

    if (grade === "F") {
        result.classList.add("fail");
    } else {
        result.classList.add("pass");
    }
});
