// Bootstrap's ScrollSpy handles active navigation.
// This small script closes the mobile menu after a navigation link is clicked.
document.querySelectorAll(".navbar-nav .nav-link").forEach(link => {
  link.addEventListener("click", () => {
    const menu = document.querySelector("#navbarContent");
    if (menu.classList.contains("show")) {
      bootstrap.Collapse.getOrCreateInstance(menu).hide();
    }
  });
});
